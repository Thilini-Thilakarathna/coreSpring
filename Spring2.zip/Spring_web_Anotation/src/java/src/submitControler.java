/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author Tharindu
 */
@Controller
public class submitControler {
//    @RequestMapping("/submit.htm")
//    public ModelAndView getData(@RequestParam("name") String t1,@RequestParam("name2") String t2){
//    ModelAndView model=new ModelAndView("index");
//        System.out.println(t1+""+t2);
//    return  model;
//    }
    @RequestMapping("/submit.htm")
    public ModelAndView getData(@ModelAttribute("data")DataHolder holder){
    ModelAndView model=new ModelAndView("index");
        System.out.println(holder.getName()+""+holder.getName2());
    return  model;
    }
}
