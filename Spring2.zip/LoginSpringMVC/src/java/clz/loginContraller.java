/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clz;

import java.util.Vector;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author Tharindu
 */
public class loginContraller extends AbstractController{

    @Override
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
       String user= request.getParameter("user");
       
       ModelAndView ob=null;
       if(user.equals("Tharindu")){
       ob=new ModelAndView("WelcomePage");
       Holder ho=new Holder();
       ho.setName("Tharindu");
       ho.setAge("24");
       ob.addObject("dataholder",ho);
       Vector v=new Vector();
       v.add("Vec Data");
       v.add("Data Deka");
       v.add("Data Thuna");
     
       ob.addObject("vector",v);
       }else{
       ob=new ModelAndView("ErrorPage");
       }
       return ob;
    }
    
}
